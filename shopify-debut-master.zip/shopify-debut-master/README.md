# Shopify Theme example for GitHub Actions

[![Build Status](https://github.com/pgrimaud/shopify-debut/workflows/Deploy%20Shopify%20Theme/badge.svg)](https://github.com/pgrimaud/shopify-debut/actions)

This repository is an example for the following GitHub Actions : https://github.com/pgrimaud/action-shopify
